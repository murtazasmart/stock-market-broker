import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shareprice',
  templateUrl: './shareprice.component.html',
  styleUrls: ['./shareprice.component.scss']
})
export class SharepriceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  
}
