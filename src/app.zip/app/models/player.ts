export class Player
{
    constructor(
        public name : string, 
        public accountNumber: number,
        public stockValues : number, 
        public cashValue : number
    ) {}
}