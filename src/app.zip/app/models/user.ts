export class User
{
    name : string;
    accountID?: string;
    isLoggedIn?: boolean;
}