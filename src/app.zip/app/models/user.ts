export class User
{
    Name : string;
    accountNumber?: number;
    isLoggedIn?: boolean;
}