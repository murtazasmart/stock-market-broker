export class Account
{
    name:string;
    accountID:string;
}