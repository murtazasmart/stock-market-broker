export class Stock
{
    company : string;
    price: number;
    round: number;
    sector: string;
}