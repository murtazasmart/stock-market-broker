export class Stock {
  constructor(
      public company: string, 
      public price: number, 
      public round: number, 
      public sector: string
    ) {}
}
