export class Trend
{
    constructor(
        public action : string, 
        public duration : string, 
        public name : string, 
        public rectime : string, 
        public type : string) {}
}